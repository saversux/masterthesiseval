import pandas
import os

if os.path.exists('stats.txt'):
    os.remove('stats.txt')

for y in ['1k', '5k']:
    for x in ['big', 'small']:
        out = open('stats.txt', 'a')

        data = pandas.read_csv('data/' + x + y + '.txt')
        data = data.div(1000000)
        plot = data.plot()
        plot.set_xlabel('call no')
        plot.set_ylabel('time in ms')
        plot.get_figure().savefig(x + y + '.pdf', format='pdf')

        out.write(x + y + '\n')
        out.write('------------------\n')
        out.write(str(data.describe()) + '\n')
        out.write('90% ' + str(data.quantile(0.9).values[0]) + '\n')
        out.write('------------------\n\n')
        out.close