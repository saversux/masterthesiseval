import pandas
import os
import matplotlib.pyplot as plt

if os.path.exists('stats.txt'):
    os.remove('stats.txt')

color = ['r', 'b', 'g', 'olive']
peers = ['0x4CA9', '0x8E2F', '0xB1BD', '0xFA35', 'Gesamt']

i = 0
for y in peers:
    out = open('stats.txt', 'a')

    data = pandas.read_csv('data/' + y + '.txt')
    data = data.div(1000000)
    if y != 'Gesamt':
        plt.plot(data, label=y)
    out.write(y + '\n')
    out.write('------------------\n')
    out.write(str(data.describe()) + '\n')
    out.write('90% ' + str(data.quantile(0.9).values[0]) + '\n')
    out.write('------------------\n\n')
    out.close
    i = i + 1

plt.xlabel('call no')
plt.ylabel('time in ms')
plt.legend(peers)
plt.savefig('all.pdf', format='pdf')
